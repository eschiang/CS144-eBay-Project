Partner 1: Meet Bhagdev
ID: 104079094
Email: meetbhagdev@ucla.edu

Partner 2: Joshua Dykstra
ID: 903888459
Email: dykstrajj@gmail.com

Josh wrote the sql script and the submission page.  Meet wrote the inital Java class with changes made in partner coding.  
