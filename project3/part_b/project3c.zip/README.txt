README.txt

Josh Dykstra
903888459
dykstrajj@gmail.com

Meet Bhagdev
104079094
meetbhagdev@ucla.edu

All parts of the spec were met.